import React from 'react';

import Welcome from './components/Welcome'
import Login from './components/Login';
import Signup from './components/Signup';
import {createStackNavigator} from '@react-navigation/stack';
import {NavigationContainer} from '@react-navigation/native';
import Category from './components/Category';
import Vegetablecard from './components/Vegetablecard';
import Fruitcard from './components/Fruitcard';
import Payment from './components/Payment'
const Stack=createStackNavigator()
const App=()=>{
  return(
    <NavigationContainer >
   <Stack.Navigator>
     <Stack.Screen  name="Lets Buy From The Farmers Directly" component={Welcome}/>
     <Stack.Screen  name="LOGIN NOW" component={Login}/>
     <Stack.Screen  name="SIGN UP NOW" component={Signup}/>
     <Stack.Screen  name="Choose The Category" component={Category}/>
     <Stack.Screen  name="Buy Fresh Quality" component={Vegetablecard}/>
     <Stack.Screen  name="Buy Fresh Quality Fruit" component={Fruitcard}/>
     <Stack.Screen  name="Do the payment" component={Payment}/>
   </Stack.Navigator>
   </NavigationContainer>
  )
}
export default App 