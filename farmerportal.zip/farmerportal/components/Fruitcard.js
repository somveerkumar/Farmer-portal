import {View,Text,Image,TouchableOpacity, ScrollView} from 'react-native'
import React from 'react'
const Fruitcard=({navigation})=>{
    return(
        <View>
            <ScrollView>
            <View>
            <View  style={{flexDirection:'row'}}>
            <View>
            <Image style={{resizeMode:'cover',height:150,borderRadius:15,width:180,padding:10}} source={require("./apple.jpg")}/>
            </View>
            <View style={{justifyContent:'center',alignItems:'center',padding:10}}>
            <Text style={{fontSize:20,color:'black'}}>Apple</Text>
            <Text>Fresh Apple</Text>
            <Text>RS 80/kg</Text>
            <TouchableOpacity style={{justifyContent:'center',alignItems:'center',marginVertical:30}}  onPress={()=>{navigation.navigate("Do the payment")}}>
                <Text style={{fontSize:18,color:'green' ,fontFamily:'sens-serif',padding:8}}>Add Item</Text>
            </TouchableOpacity>
            </View>
            </View>
            </View>

            <View>
            <View  style={{flexDirection:'row'}}>
            <View>
            <Image style={{resizeMode:'cover',height:150,borderRadius:15,width:180,padding:10}} source={require("./mango.jpeg")}/>
            </View>
            <View style={{justifyContent:'center',alignItems:'center',padding:10}}>
            <Text style={{fontSize:20,color:'black'}}>Mango</Text>
            <Text>Fresh Mango</Text>
            <Text>RS 120/kg</Text>
            <TouchableOpacity style={{justifyContent:'center',alignItems:'center',marginVertical:30}}  onPress={()=>{navigation.navigate("Do the payment")}}>
                <Text style={{fontSize:18,color:'green' ,fontFamily:'sens-serif',padding:8}}>Add Item</Text>
            </TouchableOpacity>
            </View>
            </View>
            </View>

            <View>
            <View  style={{flexDirection:'row'}}>
            <View>
            <Image style={{resizeMode:'cover',height:150,borderRadius:15,width:180,padding:10}} source={require("./grapes.jpeg")}/>
            </View>
            <View style={{justifyContent:'center',alignItems:'center',padding:10}}>
            <Text style={{fontSize:20,color:'black'}}>Grapes</Text>
            <Text>Fresh grapes</Text>
            <Text>RS 60/kg</Text>
            <TouchableOpacity style={{justifyContent:'center',alignItems:'center',marginVertical:30}}  onPress={()=>{navigation.navigate("Do the payment")}}>
                <Text style={{fontSize:18,color:'green' ,fontFamily:'sens-serif',padding:8}}>Add Item</Text>
            </TouchableOpacity>
            </View>
            </View>
            </View>

            <View>
            <View  style={{flexDirection:'row'}}>
            <View>
            <Image style={{resizeMode:'cover',height:150,borderRadius:15,width:180,padding:10}} source={require("./papaya.jpeg")}/>
            </View>
            <View style={{justifyContent:'center',alignItems:'center',padding:10}}>
            <Text style={{fontSize:20,color:'black'}}>Papaya</Text>
            <Text>Fresh papaya</Text>
            <Text>RS 70/kg</Text>
            <TouchableOpacity style={{justifyContent:'center',alignItems:'center',marginVertical:30}}  onPress={()=>{navigation.navigate("Do the payment")}}>
                <Text style={{fontSize:18,color:'green' ,fontFamily:'sens-serif',padding:8}}>Add Item</Text>
            </TouchableOpacity>
            </View>
            </View>
            </View>

            <View>
            <View  style={{flexDirection:'row'}}>
            <View>
            <Image style={{resizeMode:'cover',height:150,borderRadius:15,width:180,padding:10}} source={require("./guava.jpeg")}/>
            </View>
            <View style={{justifyContent:'center',alignItems:'center',padding:10}}>
            <Text style={{fontSize:20,color:'black'}}>Guava</Text>
            <Text>Fresh Guava</Text>
            <Text>RS 25/kg</Text>
            <TouchableOpacity style={{justifyContent:'center',alignItems:'center',marginVertical:30}}  onPress={()=>{navigation.navigate("Do the payment")}}>
                <Text style={{fontSize:18,color:'green' ,fontFamily:'sens-serif',padding:8}}>Add Item</Text>
            </TouchableOpacity>
            </View>
            </View>
            </View>
            </ScrollView>
        </View>
    )
}
export default Fruitcard