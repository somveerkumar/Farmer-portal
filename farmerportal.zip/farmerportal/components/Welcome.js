/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

 
import React from 'react';

 import {
  
   StyleSheet,
   Text,
   TouchableOpacity,
   useColorScheme,
   View,
 } from 'react-native';
 
 import {
   Colors,
  
 } from 'react-native/Libraries/NewAppScreen';
 
 
 
 const Welcome = ({navigation}) => {
   const isDarkMode = useColorScheme() === 'dark';
 
  
 
   return (
         <View
           style={{
             backgroundColor: isDarkMode ? Colors.black : Colors.white,
             justifyContent:'center',
             alignItems:'center',
             flex:1,
             
           }}>
           <View style={{justifyContent:'center',alignItems:'center',flex:0.3}}>
          <TouchableOpacity 
          style={{margin:10,backgroundColor:'pink',height:60,justifyContent:'center',alignItems:'center',width:200,borderRadius:50}}
          onPress={()=>navigation.navigate("LOGIN NOW")}
          >
            <Text style={{color:'blue',fontSize:18}}>LOGIN</Text>
          </TouchableOpacity>
          </View>
 
          <View style={{justifyContent:'center',alignItems:'center',flex:0.2}}>
          <TouchableOpacity style={{margin:10,backgroundColor:'pink',height:60,justifyContent:'center',alignItems:'center',width:200,borderRadius:50}}
           onPress={()=>navigation.navigate("SIGN UP NOW")}>
            <Text style={{color:'blue',fontSize:18}}>SIGN UP</Text>
          </TouchableOpacity>
          </View>
         </View>
      
  
   );
 };
 
 const styles = StyleSheet.create({
   sectionContainer: {
     marginTop: 32,
     paddingHorizontal: 24,
   },
   sectionTitle: {
     fontSize: 24,
     fontWeight: '600',
   },
   sectionDescription: {
     marginTop: 8,
     fontSize: 18,
     fontWeight: '400',
   },
   highlight: {
     fontWeight: '700',
   },
 });
 
 export default Welcome;
 
