import {View,StyleSheet, Text,TextInput,TouchableOpacity} from 'react-native';
import React, { useState }  from 'react';


const Login =({navigation})=>{
     
    const [username,setUsername]=useState('')
    const [password,setPassword]=useState('')
    console.log(username + password)
   
    
    return(
    <View>
    <View >  
    <View style={styles.v2}>
    <TextInput style={{padding:20,fontSize:18}} placeholder="Enter Email" onChangeText={setUsername}/>
    <TextInput style={{padding:20,fontSize:18}} placeholder="Enter Password" onChangeText={setPassword}/>

    <View style={styles.v3}>
    <TouchableOpacity
     style={{backgroundColor:"white",borderRadius:10,height:30,justifyContent:'center',alignItems:'center',width:80}} 
     onPress={()=>navigation.navigate("Choose The Category")}> 
    <Text style={{color:"blue",fontSize:16}}>SIGN IN</Text>
    </TouchableOpacity>

    <TouchableOpacity style={{backgroundColor:"white",borderRadius:10,height:30,justifyContent:'center',alignItems:'center',width:80}}
     onPress={()=>navigation.navigate("SIGN UP NOW")}> 
    <Text style={{color:"blue",fontSize:16}}>SIGN UP</Text>
    </TouchableOpacity>

   
    </View>
    </View>
    </View>
    </View>
   
    )
    }

const styles=StyleSheet.create({
   
    v2:{
       justifyContent:'center',
       elevation:14,
       shadowColor:'#000000',
       shadowOffset:{width:1,height:7},
       shadowRadius:10,
       shadowOpacity:0.5,
       backgroundColor:'pink',
       marginVertical:70,
       marginHorizontal:20,
       borderRadius:20,
       opacity:0.9


    },
  
    v3:{
        
        flexDirection:'row',
        justifyContent:'space-between',
        paddingHorizontal:90,
        paddingVertical:30
    },
 
})

export default Login