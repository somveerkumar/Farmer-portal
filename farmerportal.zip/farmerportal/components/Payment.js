import {View,StyleSheet,Text, TextInput, TouchableOpacity} from 'react-native';
import React  from 'react';
import {useState} from 'react';
import { ScrollView } from 'react-native-gesture-handler';
const Payment=({navigation})=>{
    
   
   const [username,setUsername]=useState('')
   const [role,setRole]=useState('')
   const [password,setPassword]=useState('')
   
  
  
    const getStatus=()=>{
            const userData={
            username:username,
            role:role,
            password:password,
            history:history
            }
       
       console.log(userData)
    }
    


   return(
    <View style={{justifyContent:'center',alignItems:'center'}}>
    <ScrollView>
    <Text style={{fontSize:18,padding:10,color:'green',}}>ENTER YOUR LOCATION DETAILS BELOW</Text>
    <View >
    <View style={styles.v2}>
    <TextInput style={{padding:15,fontSize:18}} placeholder="Address line 1 ..."  onChangeText={setUsername}/>
    <TextInput style={{padding:15,fontSize:18}} placeholder="Address line 2 ..."  onChangeText={setUsername}/>
    <TextInput style={{padding:15,fontSize:18}} placeholder="Mobile Number" onChangeText={setRole}/>
    <TextInput style={{padding:15,fontSize:18}} placeholder="City" onChangeText={setRole}/>
    <TextInput style={{padding:15,fontSize:18}} placeholder="State " onChangeText={setRole}/>
    <TextInput style={{padding:15,fontSize:18}} placeholder="Area Pin Code" onChangeText={setPassword}/>
    
    <View style={styles.v3}>
    <TouchableOpacity style={{backgroundColor:"white",borderRadius:10,height:30,justifyContent:'center',alignItems:'center',width:80}}    onPress={()=>navigation.navigate("LOGIN NOW")}> 
    <Text style={{color:"blue",fontSize:16}}>PAY</Text>
    </TouchableOpacity>
    </View>
    </View>
   
    </View>
    </ScrollView>
    </View>
   
    )
}

const styles=StyleSheet.create({
   
    v2:{
      justifyContent:'center',
       elevation:14,
       shadowColor:'#000000',
       shadowOffset:{width:1,height:7},
       shadowRadius:10,
       shadowOpacity:0.5,
       backgroundColor:'pink',
       marginVertical:70,
       marginHorizontal:20,
       borderRadius:20,
       opacity:0.9


    },
  
    v3:{
        
        flexDirection:'row',
        justifyContent:'center',
        paddingHorizontal:90,
        paddingVertical:30
    },
 
})
export default Payment
