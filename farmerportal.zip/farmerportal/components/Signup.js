import {View,StyleSheet,Text, TextInput, TouchableOpacity} from 'react-native';
import React  from 'react';
import {useState} from 'react';
import { ScrollView } from 'react-native-gesture-handler';
const Signup=({navigation})=>{
    
   
   const [username,setUsername]=useState('')
   const [role,setRole]=useState('')
   const [password,setPassword]=useState('')
   
  
  
    const getStatus=()=>{
            const userData={
            username:username,
            role:role,
            password:password,
            history:history
            }
       
       console.log(userData)
    }
    


   return(
    <View>
    <ScrollView>
    <View >
    <View style={styles.v2}>
    <TextInput style={{padding:15,fontSize:18}} placeholder="Enter Your Full Name"  onChangeText={setUsername}/>
    <TextInput style={{padding:15,fontSize:18}} placeholder="Mobile Number" onChangeText={setRole}/>
    <TextInput style={{padding:15,fontSize:18}} placeholder="Email Address" onChangeText={setRole}/>
    <TextInput style={{padding:15,fontSize:18}} placeholder="Password " onChangeText={setRole}/>
    <TextInput style={{padding:15,fontSize:18}} placeholder="Confirm password" onChangeText={setPassword}/>

    <View style={styles.v3}>
    <TouchableOpacity style={{backgroundColor:"white",borderRadius:10,height:30,justifyContent:'center',alignItems:'center',width:80}}    onPress={()=>navigation.navigate("LOGIN NOW")}> 
    <Text style={{color:"blue",fontSize:16}}>SIGN UP</Text>
    </TouchableOpacity>

    <TouchableOpacity style={{backgroundColor:"white",borderRadius:10,height:30,justifyContent:'center',alignItems:'center',width:80}} onPress={()=>navigation.navigate("LOGIN NOW")}> 
    <Text style={{color:"blue",fontSize:16}}>SIGN IN</Text>
    </TouchableOpacity>
    </View>
    </View>
   
    </View>
    </ScrollView>
    </View>
   
    )
}

const styles=StyleSheet.create({
   
    v2:{
      justifyContent:'center',
       elevation:14,
       shadowColor:'#000000',
       shadowOffset:{width:1,height:7},
       shadowRadius:10,
       shadowOpacity:0.5,
       backgroundColor:'pink',
       marginVertical:70,
       marginHorizontal:20,
       borderRadius:20,
       opacity:0.9


    },
  
    v3:{
        
        flexDirection:'row',
        justifyContent:'space-between',
        paddingHorizontal:90,
        paddingVertical:30
    },
 
})
export default Signup
