import {View,Text,Image,TouchableOpacity} from 'react-native'
import React from 'react'
const Category=({navigation})=>{
    return(
        <View>
            <TouchableOpacity style={{justifyContent:'center',alignItems:'center',marginVertical:30}} onPress={()=>{navigation.navigate("Buy Fresh Quality")}}>
                <Text style={{fontSize:18,color:'green' ,fontFamily:'sens-serif',padding:8}}>VEGETABLES</Text>

                <Image style={{resizeMode:'cover',height:180,borderRadius:10,width:180,borderRadius:10}} source={require("./veg.jpg")}/>
            </TouchableOpacity>

            <TouchableOpacity style={{justifyContent:'center',alignItems:'center',marginVertical:20}} onPress={()=>{navigation.navigate("Buy Fresh Quality Fruit")}}>
                <Text style={{fontSize:18,color:'green' ,fontFamily:'sens-serif',padding:8}}>FRUITS</Text>
               <Image style={{resizeMode:'cover',height:180,borderRadius:10,width:180,borderRadius:10}} source={require("./fruit.jpeg")}/>
            </TouchableOpacity>

        </View>
    )
}
export default Category