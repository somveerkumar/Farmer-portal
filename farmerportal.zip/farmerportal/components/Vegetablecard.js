import {View,Text,Image,TouchableOpacity, ScrollView} from 'react-native'
import React from 'react'
const Vegetablecard=({navigation})=>{
    return(
        <View>
            <ScrollView>
            <View>
            <View  style={{flexDirection:'row'}}>
            <View>
            <Image style={{resizeMode:'cover',height:150,borderRadius:15,width:180,padding:10}} source={require("./tomato.jpeg")}/>
            </View>
            <View style={{justifyContent:'center',alignItems:'center',padding:10}}>
            <Text style={{fontSize:20,color:'black'}}>Tomato</Text>
            <Text>Fresh Tomato</Text>
            <Text>RS 20/kg</Text>
            <TouchableOpacity style={{justifyContent:'center',alignItems:'center',marginVertical:30}} onPress={()=>{navigation.navigate("Do the payment")}}>
                <Text style={{fontSize:18,color:'green' ,fontFamily:'sens-serif',padding:8}}>Add Item</Text>
            </TouchableOpacity>
            </View>
            </View>
            </View>

            <View>
            <View  style={{flexDirection:'row'}}>
            <View>
            <Image style={{resizeMode:'cover',height:150,borderRadius:15,width:180,padding:10}} source={require("./onion.jpeg")}/>
            </View>
            <View style={{justifyContent:'center',alignItems:'center',padding:10}}>
            <Text style={{fontSize:20,color:'black'}}>Onion</Text>
            <Text>Fresh Onion</Text>
            <Text>RS 30/kg</Text>
            <TouchableOpacity style={{justifyContent:'center',alignItems:'center',marginVertical:30}} onPress={()=>{navigation.navigate("Do the payment")}}>
                <Text style={{fontSize:18,color:'green' ,fontFamily:'sens-serif',padding:8}}>Add Item</Text>
            </TouchableOpacity>
            </View>
            </View>
            </View>

            <View>
            <View  style={{flexDirection:'row'}}>
            <View>
            <Image style={{resizeMode:'cover',height:150,borderRadius:15,width:180,padding:10}} source={require("./potato.jpeg")}/>
            </View>
            <View style={{justifyContent:'center',alignItems:'center',padding:10}}>
            <Text style={{fontSize:20,color:'black'}}>Potato</Text>
            <Text>Fresh Potato</Text>
            <Text>RS 40/kg</Text>
            <TouchableOpacity style={{justifyContent:'center',alignItems:'center',marginVertical:30}} onPress={()=>{navigation.navigate("Do the payment")}}>
                <Text style={{fontSize:18,color:'green' ,fontFamily:'sens-serif',padding:8}}>Add Item</Text>
            </TouchableOpacity>
            </View>
            </View>
            </View>

            <View>
            <View  style={{flexDirection:'row'}}>
            <View>
            <Image style={{resizeMode:'cover',height:150,borderRadius:15,width:180,padding:10}} source={require("./cauli.jpeg")}/>
            </View>
            <View style={{justifyContent:'center',alignItems:'center',padding:10}}>
            <Text style={{fontSize:20,color:'black'}}>Cauliflower</Text>
            <Text>Fresh Cauliflower</Text>
            <Text>RS 25/kg</Text>
            <TouchableOpacity style={{justifyContent:'center',alignItems:'center',marginVertical:30}} onPress={()=>{navigation.navigate("Do the payment")}}>
                <Text style={{fontSize:18,color:'green' ,fontFamily:'sens-serif',padding:8}}>Add Item</Text>
            </TouchableOpacity>
            </View>
            </View>
            </View>

            <View>
            <View  style={{flexDirection:'row'}}>
            <View>
            <Image style={{resizeMode:'cover',height:150,borderRadius:15,width:180,padding:10}} source={require("./cabbage.jpeg")}/>
            </View>
            <View style={{justifyContent:'center',alignItems:'center',padding:10}}>
            <Text style={{fontSize:20,color:'black'}}>Cabbage</Text>
            <Text>Fresh cabbage</Text>
            <Text>RS 35/kg</Text>
            <TouchableOpacity style={{justifyContent:'center',alignItems:'center',marginVertical:30}} onPress={()=>{navigation.navigate("Do the payment")}}>
                <Text style={{fontSize:18,color:'green' ,fontFamily:'sens-serif',padding:8}}>Add Item</Text>
            </TouchableOpacity>
            </View>
            </View>
            </View>
            </ScrollView>
        </View>
    )
}
export default Vegetablecard